import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Accommodation } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, Check, Star } from "lucide-react";
import { searchHotels } from "@/lib/api";
import { format } from "date-fns";

type AccommodationPickerProps = {
  tripId: number;
  startDate: string;
  endDate: string;
  destination: string;
};

export default function AccommodationPicker({ 
  tripId, 
  startDate, 
  endDate, 
  destination 
}: AccommodationPickerProps) {
  const { data: savedAccommodations, isLoading: savedLoading } = useQuery<Accommodation[]>({
    queryKey: [`/api/trips/${tripId}/accommodations`],
  });

  const { data: hotels, isLoading: hotelsLoading } = useQuery({
    queryKey: ['hotels', destination, startDate, endDate],
    queryFn: () => searchHotels(
      destination,
      format(new Date(startDate), 'yyyy-MM-dd'),
      format(new Date(endDate), 'yyyy-MM-dd')
    ),
    enabled: Boolean(destination && startDate && endDate),
  });

  const updateAccommodationMutation = useMutation({
    mutationFn: async ({ id, selected }: { id: number; selected: boolean }) => {
      const res = await apiRequest("PATCH", `/api/accommodations/${id}`, {
        selected,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [`/api/trips/${tripId}/accommodations`],
      });
    },
  });

  if (savedLoading || hotelsLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!hotels?.length) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">No accommodations found for this destination and dates.</p>
      </div>
    );
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      {hotels.map((hotel) => {
        const isSelected = savedAccommodations?.some(
          (a) => a.id === hotel.id && a.selected
        );

        return (
          <Card
            key={hotel.id}
            className={`overflow-hidden transition-colors ${
              isSelected ? "ring-2 ring-primary" : ""
            }`}
          >
            <img
              src={hotel.imageUrl}
              alt={hotel.name}
              className="w-full h-48 object-cover"
            />
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-4">
                <div className="space-y-2">
                  <h3 className="font-semibold">{hotel.name}</h3>
                  <p className="text-sm text-muted-foreground">{hotel.location}</p>
                  {hotel.rating && (
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm">{hotel.rating}</span>
                      {hotel.reviewsCount && (
                        <span className="text-sm text-muted-foreground">
                          ({hotel.reviewsCount} reviews)
                        </span>
                      )}
                    </div>
                  )}
                  <p className="text-sm">{hotel.roomType}</p>
                  <p className="text-2xl font-bold">
                    {hotel.currency} {hotel.price}
                  </p>
                  <p className="text-sm text-muted-foreground">total for stay</p>
                </div>
                <Button
                  variant={isSelected ? "default" : "outline"}
                  size="sm"
                  onClick={() =>
                    updateAccommodationMutation.mutate({
                      id: hotel.id,
                      selected: !isSelected,
                    })
                  }
                  disabled={updateAccommodationMutation.isPending}
                >
                  {isSelected ? (
                    <>
                      <Check className="h-4 w-4 mr-2" />
                      Selected
                    </>
                  ) : (
                    "Select"
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}