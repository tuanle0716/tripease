import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CarRental } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, Check } from "lucide-react";

const MOCK_CAR_RENTALS = [
  {
    id: 1,
    name: "Luxury Sedan",
    imageUrl: "https://images.unsplash.com/photo-1568288564902-dead3b6fe60c",
    price: "89",
  },
  {
    id: 2,
    name: "SUV",
    imageUrl: "https://images.unsplash.com/photo-1644578616497-a73f8004d5fb",
    price: "120",
  },
  {
    id: 3,
    name: "Economy Car",
    imageUrl: "https://images.unsplash.com/photo-1590761697430-e6845a05d987",
    price: "45",
  },
  {
    id: 4,
    name: "Sports Car",
    imageUrl: "https://images.unsplash.com/photo-1587580945215-5d4aabb2c8ef",
    price: "150",
  },
];

type CarRentalPickerProps = {
  tripId: number;
};

export default function CarRentalPicker({ tripId }: CarRentalPickerProps) {
  const { data: carRentals, isLoading } = useQuery<CarRental[]>({
    queryKey: [`/api/trips/${tripId}/car-rentals`],
  });

  const updateCarRentalMutation = useMutation({
    mutationFn: async ({ id, selected }: { id: number; selected: boolean }) => {
      const res = await apiRequest("PATCH", `/api/car-rentals/${id}`, {
        selected,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [`/api/trips/${tripId}/car-rentals`],
      });
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      {MOCK_CAR_RENTALS.map((car) => {
        const isSelected = carRentals?.some(
          (c) => c.id === car.id && c.selected
        );

        return (
          <Card
            key={car.id}
            className={`overflow-hidden transition-colors ${
              isSelected ? "ring-2 ring-primary" : ""
            }`}
          >
            <img
              src={car.imageUrl}
              alt={car.name}
              className="w-full h-48 object-cover"
            />
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-semibold">{car.name}</h3>
                  <p className="text-2xl font-bold">${car.price}</p>
                  <p className="text-sm text-muted-foreground">per day</p>
                </div>
                <Button
                  variant={isSelected ? "default" : "outline"}
                  size="sm"
                  onClick={() =>
                    updateCarRentalMutation.mutate({
                      id: car.id,
                      selected: !isSelected,
                    })
                  }
                  disabled={updateCarRentalMutation.isPending}
                >
                  {isSelected ? (
                    <>
                      <Check className="h-4 w-4 mr-2" />
                      Selected
                    </>
                  ) : (
                    "Select"
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
