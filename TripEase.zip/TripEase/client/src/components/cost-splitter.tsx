import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { TripMember } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { apiRequest, queryClient } from "@/lib/queryClient";

type CostSplitterProps = {
  tripId: number;
  members: TripMember[];
  totalCost: number;
  onUpdate: (cost: number) => void;
};

export default function CostSplitter({
  tripId,
  members,
  totalCost,
  onUpdate,
}: CostSplitterProps) {
  const [dueDate, setDueDate] = useState<Date>();
  const [splits, setSplits] = useState<Record<number, number>>(
    Object.fromEntries(members.map((m) => [m.id, 0]))
  );

  const updateMemberMutation = useMutation({
    mutationFn: async ({
      memberId,
      splitPercentage,
      paymentDueDate,
    }: {
      memberId: number;
      splitPercentage: number;
      paymentDueDate?: string;
    }) => {
      const res = await apiRequest(
        "PATCH",
        `/api/trips/${tripId}/members/${memberId}`,
        {
          splitPercentage,
          paymentDueDate,
        }
      );
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [`/api/trips/${tripId}/members`],
      });
    },
  });

  const handleSplitChange = (memberId: number, value: string) => {
    const percentage = Math.min(100, Math.max(0, parseFloat(value) || 0));
    setSplits({ ...splits, [memberId]: percentage });
  };

  const handleSave = () => {
    const total = Object.values(splits).reduce((sum, val) => sum + val, 0);
    if (total !== 100) {
      alert("Total split percentage must equal 100%");
      return;
    }

    members.forEach((member) => {
      updateMemberMutation.mutate({
        memberId: member.id,
        splitPercentage: splits[member.id],
        paymentDueDate: dueDate?.toISOString(),
      });
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="pt-6">
          <div className="mb-6">
            <Label>Total Trip Cost</Label>
            <div className="flex items-center gap-4 mt-2">
              <Input
                type="number"
                value={totalCost}
                onChange={(e) => onUpdate(parseFloat(e.target.value) || 0)}
                className="max-w-[200px]"
              />
              <span className="text-muted-foreground">USD</span>
            </div>
          </div>

          <div className="mb-6">
            <Label>Payment Due Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-[200px] justify-start text-left font-normal mt-2",
                    !dueDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dueDate ? format(dueDate, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={dueDate}
                  onSelect={setDueDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-4">
            <Label>Cost Split</Label>
            {members.map((member) => (
              <div key={member.id} className="flex items-center gap-4">
                <Input
                  type="number"
                  value={splits[member.id]}
                  onChange={(e) => handleSplitChange(member.id, e.target.value)}
                  className="max-w-[100px]"
                />
                <span className="text-muted-foreground">%</span>
                <span>
                  (${((splits[member.id] / 100) * totalCost).toFixed(2)})
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Button
        className="w-full"
        onClick={handleSave}
        disabled={updateMemberMutation.isPending}
      >
        {updateMemberMutation.isPending ? "Saving..." : "Save Split"}
      </Button>
    </div>
  );
}
