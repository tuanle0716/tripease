import { Trip } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { format } from "date-fns";
import { MapPin } from "lucide-react";

type TripCardProps = {
  trip: Trip;
};

export default function TripCard({ trip }: TripCardProps) {
  return (
    <Link href={`/trips/${trip.id}`}>
      <Card className="hover:bg-muted/50 transition-colors cursor-pointer">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <CardTitle className="text-lg">{trip.name}</CardTitle>
            <Badge
              variant={
                trip.status === "planning"
                  ? "outline"
                  : trip.status === "booked"
                  ? "default"
                  : "secondary"
              }
            >
              {trip.status}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex items-center text-muted-foreground">
              <MapPin className="h-4 w-4 mr-2" />
              {trip.destination}
            </div>
            <div className="text-sm text-muted-foreground">
              {format(new Date(trip.startDate), "MMM d")} -{" "}
              {format(new Date(trip.endDate), "MMM d, yyyy")}
            </div>
            {parseFloat(trip.totalCost.toString()) > 0 && (
              <div className="font-semibold mt-2">
                Total: ${parseFloat(trip.totalCost.toString()).toFixed(2)}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
