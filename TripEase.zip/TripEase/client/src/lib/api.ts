import { env } from "./env";

const RAPIDAPI_BASE_URL = "https://hotels-com-provider.p.rapidapi.com/v2";

const rapidApiHeaders = {
  'X-RapidAPI-Key': env.RAPIDAPI_KEY,
  'X-RapidAPI-Host': 'hotels-com-provider.p.rapidapi.com'
};

export async function searchHotels(destination: string, checkIn: string, checkOut: string) {
  const searchParams = new URLSearchParams({
    destination,
    checkin: checkIn,
    checkout: checkOut
  });

  const response = await fetch(
    `/api/rapidapi/hotels?${searchParams}`,
    { credentials: 'include' }
  );

  if (!response.ok) {
    throw new Error('Failed to fetch accommodations');
  }

  const data = await response.json();

  if (!data.results) {
    return [];
  }

  return data.results.map((property: any) => ({
    id: property.id,
    name: property.name,
    imageUrl: property.images[0] || '',
    price: property.price.total,
    currency: property.price.currency,
    rating: property.rating,
    location: property.address,
    roomType: property.roomType,
    reviewsCount: property.reviewsCount
  }));
}

export async function searchCarRentals(location: string, pickupDate: string, returnDate: string) {
  const searchParams = new URLSearchParams({
    location,
    pickup: pickupDate,
    return: returnDate
  });

  const response = await fetch(
    `/api/rapidapi/car-rentals?${searchParams}`,
    { credentials: 'include' }
  );

  if (!response.ok) {
    throw new Error('Failed to fetch car rentals');
  }

  const data = await response.json();
  return data.vehicles.map((vehicle: any) => ({
    id: vehicle.id,
    name: vehicle.name,
    imageUrl: vehicle.image?.url || '',
    price: vehicle.price.total.amount,
    currency: vehicle.price.total.currencyInfo.code,
    category: vehicle.category,
    provider: vehicle.provider.name
  }));
}