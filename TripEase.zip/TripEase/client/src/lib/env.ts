function getEnvVar(key: string): string {
  const value = import.meta.env[`VITE_${key}`];
  if (!value) {
    throw new Error(`Missing environment variable: ${key}`);
  }
  return value;
}

export const env = {
  RAPIDAPI_KEY: getEnvVar('RAPIDAPI_KEY'),
} as const;
