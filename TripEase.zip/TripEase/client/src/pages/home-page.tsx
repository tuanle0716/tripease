import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Loader2, Plus, LogOut } from "lucide-react";
import { Trip } from "@shared/schema";
import TripCard from "@/components/trip-card";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const { data: trips, isLoading, error } = useQuery<Trip[]>({
    queryKey: ["/api/trips"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen gap-4">
        <p className="text-destructive">Failed to load trips: {error.message}</p>
        <Button variant="outline" onClick={() => window.location.reload()}>
          Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Welcome, {user?.username}!</h1>
            <p className="text-muted-foreground mt-2">Manage your trips and create new adventures</p>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => logoutMutation.mutate()}>
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
            <Link href="/trips/create">
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create Trip
              </Button>
            </Link>
          </div>
        </div>

        {trips?.length === 0 ? (
          <div className="text-center py-12 bg-muted/50 rounded-lg">
            <h2 className="text-xl font-semibold mb-2">No trips planned yet</h2>
            <p className="text-muted-foreground mb-4">Start by creating your first trip</p>
            <Link href="/trips/create">
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create Trip
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {trips?.map((trip) => (
              <TripCard key={trip.id} trip={trip} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}