import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Trip, TripMember } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import AccommodationPicker from "@/components/accommodation-picker";
import CarRentalPicker from "@/components/car-rental-picker";
import CostSplitter from "@/components/cost-splitter";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function TripDetails() {
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();

  const { data: trip, isLoading: tripLoading } = useQuery<Trip>({
    queryKey: [`/api/trips/${id}`],
  });

  const { data: members, isLoading: membersLoading } = useQuery<TripMember[]>({
    queryKey: [`/api/trips/${id}/members`],
  });

  const updateTripMutation = useMutation({
    mutationFn: async (data: Partial<Trip>) => {
      const res = await apiRequest("PATCH", `/api/trips/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/trips/${id}`] });
      toast({
        title: "Trip updated",
        description: "The trip has been updated successfully.",
      });
    },
  });

  if (tripLoading || membersLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!trip) {
    return (
      <div className="container py-8">
        <p className="text-destructive">Trip not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{trip.name}</h1>
          <p className="text-muted-foreground mt-2">{trip.destination}</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Trip Planning</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="accommodations">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="accommodations">Accommodations</TabsTrigger>
                <TabsTrigger value="cars">Car Rentals</TabsTrigger>
                <TabsTrigger value="costs">Split Costs</TabsTrigger>
              </TabsList>

              <TabsContent value="accommodations" className="mt-6">
                <AccommodationPicker 
                  tripId={parseInt(id)} 
                  startDate={trip.startDate}
                  endDate={trip.endDate}
                  destination={trip.destination}
                />
              </TabsContent>

              <TabsContent value="cars" className="mt-6">
                <CarRentalPicker tripId={parseInt(id)} />
              </TabsContent>

              <TabsContent value="costs" className="mt-6">
                <CostSplitter
                  tripId={parseInt(id)}
                  members={members || []}
                  totalCost={parseFloat(trip.totalCost.toString())}
                  onUpdate={(updatedCost) =>
                    updateTripMutation.mutate({ totalCost: updatedCost })
                  }
                />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}