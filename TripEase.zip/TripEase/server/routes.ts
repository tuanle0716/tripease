import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertTripSchema, insertTripMemberSchema } from "@shared/schema";

function ensureAuthenticated(req: Express.Request, res: Express.Response, next: Express.NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Trip routes
  app.post("/api/trips", ensureAuthenticated, async (req, res) => {
    try {
      const tripData = insertTripSchema.parse({
        ...req.body,
        creatorId: req.user!.id,
      });
      const trip = await storage.createTrip(tripData);
      res.status(201).json(trip);
    } catch (error) {
      console.error('Trip creation error:', error);
      res.status(400).json({ 
        message: "Invalid trip data",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.get("/api/trips", ensureAuthenticated, async (req, res) => {
    const trips = await storage.getUserTrips(req.user!.id);
    res.json(trips);
  });

  app.get("/api/trips/:id", ensureAuthenticated, async (req, res) => {
    const trip = await storage.getTrip(parseInt(req.params.id));
    if (!trip) {
      return res.status(404).json({ message: "Trip not found" });
    }
    res.json(trip);
  });

  // Trip members routes
  app.post("/api/trips/:id/members", ensureAuthenticated, async (req, res) => {
    try {
      const memberData = insertTripMemberSchema.parse({
        ...req.body,
        tripId: parseInt(req.params.id),
      });
      const member = await storage.addTripMember(memberData);
      res.status(201).json(member);
    } catch (error) {
      res.status(400).json({ message: "Invalid member data" });
    }
  });

  app.get("/api/trips/:id/members", ensureAuthenticated, async (req, res) => {
    const members = await storage.getTripMembers(parseInt(req.params.id));
    res.json(members);
  });

  app.patch("/api/trips/:tripId/members/:id", ensureAuthenticated, async (req, res) => {
    try {
      const member = await storage.updateTripMember(parseInt(req.params.id), req.body);
      res.json(member);
    } catch (error) {
      res.status(404).json({ message: "Member not found" });
    }
  });

  // Accommodation routes
  app.get("/api/trips/:id/accommodations", ensureAuthenticated, async (req, res) => {
    const accommodations = await storage.getTripAccommodations(parseInt(req.params.id));
    res.json(accommodations);
  });

  app.patch("/api/accommodations/:id", ensureAuthenticated, async (req, res) => {
    try {
      const accommodation = await storage.updateAccommodation(parseInt(req.params.id), req.body);
      res.json(accommodation);
    } catch (error) {
      res.status(404).json({ message: "Accommodation not found" });
    }
  });

  // Car rental routes
  app.get("/api/trips/:id/car-rentals", ensureAuthenticated, async (req, res) => {
    const carRentals = await storage.getTripCarRentals(parseInt(req.params.id));
    res.json(carRentals);
  });

  app.patch("/api/car-rentals/:id", ensureAuthenticated, async (req, res) => {
    try {
      const carRental = await storage.updateCarRental(parseInt(req.params.id), req.body);
      res.json(carRental);
    } catch (error) {
      res.status(404).json({ message: "Car rental not found" });
    }
  });

  // Update the hotels endpoint to use Airbnb API
  app.get("/api/rapidapi/hotels", ensureAuthenticated, async (req, res) => {
    const { destination, checkin, checkout } = req.query;

    if (!destination || !checkin || !checkout) {
      return res.status(400).json({ message: "Missing required parameters" });
    }

    try {
      // First get destination ID
      const searchResponse = await fetch(
        `https://airbnb19.p.rapidapi.com/api/v1/searchDestination?query=${destination}`,
        {
          headers: {
            'X-RapidAPI-Key': process.env.RAPIDAPI_KEY!,
            'X-RapidAPI-Host': 'airbnb19.p.rapidapi.com'
          }
        }
      );

      if (!searchResponse.ok) {
        throw new Error('Failed to search destination');
      }

      const searchData = await searchResponse.json();
      if (!searchData.result || searchData.result.length === 0) {
        return res.json({ properties: [] });
      }

      const destinationId = searchData.result[0].id;

      // Then search properties
      const response = await fetch(
        `https://airbnb19.p.rapidapi.com/api/v1/searchPropertyByPlace?id=${destinationId}&checkin=${checkin}&checkout=${checkout}&adults=2`,
        {
          headers: {
            'X-RapidAPI-Key': process.env.RAPIDAPI_KEY!,
            'X-RapidAPI-Host': 'airbnb19.p.rapidapi.com'
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch properties');
      }

      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error('Error fetching from Airbnb API:', error);
      res.status(500).json({ message: "Failed to fetch accommodations" });
    }
  });

  app.get("/api/rapidapi/car-rentals", ensureAuthenticated, async (req, res) => {
    const { location, pickup, return: returnDate } = req.query;

    if (!location || !pickup || !returnDate) {
      return res.status(400).json({ message: "Missing required parameters" });
    }

    try {
      const response = await fetch(
        `https://hotels-com-provider.p.rapidapi.com/v2/car-rentals/search?location=${location}&pickup=${pickup}&return=${returnDate}`,
        {
          headers: {
            'X-RapidAPI-Key': process.env.RAPIDAPI_KEY!,
            'X-RapidAPI-Host': 'hotels-com-provider.p.rapidapi.com'
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch car rentals');
      }

      const data = await response.json();
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch car rentals" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}