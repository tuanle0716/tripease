import { users, trips, tripMembers, accommodations, carRentals } from "@shared/schema";
import type { InsertUser, InsertTrip, InsertTripMember, InsertAccommodation, InsertCarRental } from "@shared/schema";
import type { User, Trip, TripMember, Accommodation, CarRental } from "@shared/schema";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { db } from "./db";
import { eq } from "drizzle-orm";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Trip methods
  createTrip(trip: InsertTrip): Promise<Trip>;
  getTrip(id: number): Promise<Trip | undefined>;
  getUserTrips(userId: number): Promise<Trip[]>;
  updateTrip(id: number, trip: Partial<Trip>): Promise<Trip>;

  // Trip member methods
  addTripMember(member: InsertTripMember): Promise<TripMember>;
  getTripMembers(tripId: number): Promise<TripMember[]>;
  updateTripMember(id: number, member: Partial<TripMember>): Promise<TripMember>;

  // Accommodation methods
  addAccommodation(accommodation: InsertAccommodation): Promise<Accommodation>;
  getTripAccommodations(tripId: number): Promise<Accommodation[]>;
  updateAccommodation(id: number, accommodation: Partial<Accommodation>): Promise<Accommodation>;

  // Car rental methods
  addCarRental(carRental: InsertCarRental): Promise<CarRental>;
  getTripCarRentals(tripId: number): Promise<CarRental[]>;
  updateCarRental(id: number, carRental: Partial<CarRental>): Promise<CarRental>;

  sessionStore: session.SessionStore;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool: db.client,
      createTableIfMissing: true,
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Trip methods
  async createTrip(trip: InsertTrip): Promise<Trip> {
    const [newTrip] = await db.insert(trips).values(trip).returning();
    return newTrip;
  }

  async getTrip(id: number): Promise<Trip | undefined> {
    const [trip] = await db.select().from(trips).where(eq(trips.id, id));
    return trip;
  }

  async getUserTrips(userId: number): Promise<Trip[]> {
    return await db
      .select()
      .from(trips)
      .where(eq(trips.creatorId, userId))
      .orderBy(trips.id);
  }

  async updateTrip(id: number, tripUpdate: Partial<Trip>): Promise<Trip> {
    const [trip] = await db
      .update(trips)
      .set(tripUpdate)
      .where(eq(trips.id, id))
      .returning();
    if (!trip) throw new Error("Trip not found");
    return trip;
  }

  // Trip member methods
  async addTripMember(member: InsertTripMember): Promise<TripMember> {
    const [newMember] = await db.insert(tripMembers).values(member).returning();
    return newMember;
  }

  async getTripMembers(tripId: number): Promise<TripMember[]> {
    return await db
      .select()
      .from(tripMembers)
      .where(eq(tripMembers.tripId, tripId));
  }

  async updateTripMember(id: number, memberUpdate: Partial<TripMember>): Promise<TripMember> {
    const [member] = await db
      .update(tripMembers)
      .set(memberUpdate)
      .where(eq(tripMembers.id, id))
      .returning();
    if (!member) throw new Error("Trip member not found");
    return member;
  }

  // Accommodation methods
  async addAccommodation(accommodation: InsertAccommodation): Promise<Accommodation> {
    const [newAccommodation] = await db
      .insert(accommodations)
      .values(accommodation)
      .returning();
    return newAccommodation;
  }

  async getTripAccommodations(tripId: number): Promise<Accommodation[]> {
    return await db
      .select()
      .from(accommodations)
      .where(eq(accommodations.tripId, tripId));
  }

  async updateAccommodation(id: number, accommodationUpdate: Partial<Accommodation>): Promise<Accommodation> {
    const [accommodation] = await db
      .update(accommodations)
      .set(accommodationUpdate)
      .where(eq(accommodations.id, id))
      .returning();
    if (!accommodation) throw new Error("Accommodation not found");
    return accommodation;
  }

  // Car rental methods
  async addCarRental(carRental: InsertCarRental): Promise<CarRental> {
    const [newCarRental] = await db
      .insert(carRentals)
      .values(carRental)
      .returning();
    return newCarRental;
  }

  async getTripCarRentals(tripId: number): Promise<CarRental[]> {
    return await db
      .select()
      .from(carRentals)
      .where(eq(carRentals.tripId, tripId));
  }

  async updateCarRental(id: number, carRentalUpdate: Partial<CarRental>): Promise<CarRental> {
    const [carRental] = await db
      .update(carRentals)
      .set(carRentalUpdate)
      .where(eq(carRentals.id, id))
      .returning();
    if (!carRental) throw new Error("Car rental not found");
    return carRental;
  }
}

export const storage = new DatabaseStorage();