import { pgTable, text, serial, integer, boolean, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
});

export const trips = pgTable("trips", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  destination: text("destination").notNull(),
  creatorId: integer("creator_id").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  status: text("status").notNull().default("planning"), // planning, booked, completed
  totalCost: decimal("total_cost").notNull().default("0"),
});

export const tripMembers = pgTable("trip_members", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull(),
  userId: integer("user_id").notNull(),
  splitPercentage: decimal("split_percentage").notNull().default("0"),
  hasPaid: boolean("has_paid").notNull().default(false),
  paymentDueDate: timestamp("payment_due_date"),
});

export const accommodations = pgTable("accommodations", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull(),
  name: text("name").notNull(),
  imageUrl: text("image_url").notNull(),
  price: decimal("price").notNull(),
  selected: boolean("selected").notNull().default(false),
});

export const carRentals = pgTable("car_rentals", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull(),
  name: text("name").notNull(),
  imageUrl: text("image_url").notNull(),
  price: decimal("price").notNull(),
  selected: boolean("selected").notNull().default(false),
});

export const insertUserSchema = createInsertSchema(users);
export const insertTripSchema = createInsertSchema(trips);
export const insertTripMemberSchema = createInsertSchema(tripMembers);
export const insertAccommodationSchema = createInsertSchema(accommodations);
export const insertCarRentalSchema = createInsertSchema(carRentals);

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertTrip = z.infer<typeof insertTripSchema>;
export type InsertTripMember = z.infer<typeof insertTripMemberSchema>;
export type InsertAccommodation = z.infer<typeof insertAccommodationSchema>;
export type InsertCarRental = z.infer<typeof insertCarRentalSchema>;

export type User = typeof users.$inferSelect;
export type Trip = typeof trips.$inferSelect;
export type TripMember = typeof tripMembers.$inferSelect;
export type Accommodation = typeof accommodations.$inferSelect;
export type CarRental = typeof carRentals.$inferSelect;
